# C# Denemelerim

1-) Çok boyutlu diziler ile araba firmalarının her marka için 3 aylık satış toplamını buluyoruz, her ay için firmaların toplam satış miktarını,
markaların en çok satış yaptığı ay,her ay için en çok satışın gerçekleştirilidği markayı bulan markaları yazdıran program.

2-) Çok boyutlu diziler ile isim ve notunu yazdıran program

3-) Çok boyutlu diziler ile en büyük elemanın bulunduğu sütundaki en küçük sayıyı ve en büyük elemanın bulunduğu sütundaki sayıların toplamını
yazdıran program

4-) Çok boyutlu diziler ile tek sayılardan oluşan diziyi bulan ve tek sayılardan oluşan dizinin sıralanmış halini yazdıran program

5-) Çok boyutlu diziler ile girilen sayının faktöryelini yazdıran program

6-) Diziler ile klavyeden sayı alan ve yazdıran program

7-) Diziler ile -5 ile +5 arası 10 tane random sayı seçen ve ve kullanılan sayıların kaç kere kullanıldığını yazdıran program

8-) Diziler ile klavyeden alınan 5 tane sayıyı tek olanları ve çift olanları yazdıran program

9-) Diziler ile klavyeden girilen metindeki türkçe karakterleri yazdıran program

10-) Liste oluşturup özel komutlarını gösteren program

11-) Listeler ile random 100 sayı arasından tek ve çift sayıların kaç tane olduğunu ve ortalamasını yazdıran program

12-) Listeler ile disteye 10 tane sayı ekliyoruz daha sonra 5 tane random sayı seçip yazdırıyoruz daha sonra listeden kaldırıp kalan sayıları yazdıran program

13-) Listeler ile klavyeden metin alıp içindeki sesli harflerin sayısını sessiz harflerin sayısını ve toplam harf sayısını yazdıran program

14-) 13.sorunun 3 tane liste kullanılarak yapılmış hali

15-) Listeler ile Klavyeden girilen harfin sayısal değerini yazdıran program

16-) Listeler ile klavyeden alınan metindeki özel karakterlerin sayı değerini yazdıran program

17-) Listeler ile klavyeden alınan metindeki bütün karakterlerin sayısal değerini yazdıran program

18-) Listeler ile klavyeden fibonacci dizisi uzunluğu alan ve bunu yazdırıp bide çıkan sonuçtaki çift sayıları yazdıran program

19-) Listeler ile klavyeden 0 girilene kadar sayı alan, bunları yazdıran , pozitif sayıları yazdıran , negatif sayıları yazdıran ve pozitif ve çift sayıları yazdıran program

20-) Listeler ile klavyeden 5 tane sayı alıp bunları asal ve asal olmayanları yazdıran  ve sayıların ortalamasını yazdıran program

21-) Metotlar ile geriye değer döndürmeden parametresiz şekilde alan hesabı yapan program

22-) Metotlar ile geriye değer döndürmeden parametreli şekilde alan hesabı yapan program

23-) Metotlar ile geriye değer döndürerek parametre almayacak şekilde alan hesabı yapan program

24-) Metotlar ile geriye değer döndüren ve parametre alıcak şekilde alan hesabı yapan program

25-) Metotlar ile 
1. İki sayıdan en büyük olanı parametresiz geriye değer döndüren metotşa bulan
2. Girilen sayının faktöryelini geriye değer döndüren parametreli metotla bulan
3. Girilen sayının asal olup olmadığını geriye değer döndürmeyen parametreli metotatla bulan
4. Girilen sayıının mükemmel sayı olup olmadığını parametresiz şekilde geriye değer döndürmeyen metotla bulan
5. Girilen sayının tek mi çift mi olduğunu geriye değer döndüren parametreli metotla bulan program

26-) Metotlar ile girilen sayının faktöryelini bulan program

27-) Metotlar ile klavyeden alınan sayının fibonaccisini bulan program

28-) Metotlar ile klayvyeden girilen sayıdan 0 kadar olan sayıları toplayan program

29-) Metotlar ile klavyeden alınan üs ve taban bilgisi ile üslü sayının sonucunu yazdıran program

30-) Nesneler ile uçgenin kenar uzunluklarını yazdıran program

31-) Nesneler ile üçgenin kenar uzunluğunun 0 dan küçük bir değer girilirse hata mesajı vericek şekilde yazan program

32-) Nesneler ile kenarlara get-set değeri atayarak üçgen kenarlarını yazdıran program

33-) Nesneler ile kenarları geriye değer döndüren ve üçgenin çevresini yazdıran program

34-) Polimorfizmi çıplak şekilde gösteren program

35-) Polimorfizm ile Araçlar aslı diziye atayarak hepsi için farklı metin yazdıran program

36-) Polimorfizm ile Her Hayvan için farklı ses çıkartan (metin yazdıran) program

37-) Polimorfizm Polimorfizm ile yönetici sınıfındaki depertman karı 500000 büyükse çalışan sınıfındakilere 2000 birim zam yapan program

38-) Polimorfizm ile 3 tane farklı ürünün kdv sini hesaplayıp sepete ekleyince satış fiyatını yazdıran program

Projemi incelediğiniz için teşekkür ederim umarım işinize yarar :)
